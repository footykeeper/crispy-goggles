# psychic-spork
Soccer game goal tracker

This web app allows you to input your roster, goals, and assists.
In the end, a table displaying players, their numbers, their goals, and their assists appears.
Ideally, you would print out the table in the end.
To use this tracker, go to http://footykeeper.com
